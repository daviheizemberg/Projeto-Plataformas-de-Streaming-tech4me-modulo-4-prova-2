package br.com.tech4me.tech4stream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tech4streamApplicationTests {

	@Test
	void contextLoads() {
	}

}
