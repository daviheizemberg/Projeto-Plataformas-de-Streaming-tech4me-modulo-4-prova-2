package br.com.tech4me.tech4plataforma.model;

public enum FormaPagamento {
    A_VISTA,
    CREDITO,
    DEBITO,
    PIX,
    BOLETO
}
