package br.com.tech4me.tech4midia.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("midia")
public class Midia {
    
    @Id
    private String id;
    private String descricao;
    private String genero;
    private double nota;
    private String idPlataforma;
    private Integer anoLancamento;

    public String getId() {
        return this.id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getDescricao() {
        return this.descricao;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    public String getGenero() {
        return this.genero;
    }
    public void setGenero(String genero) {
        this.genero = genero;
    }
    public double getNota() {
        return this.nota;
    }
    public void setNota(double nota) {
        this.nota = nota;
    }
    public String getIdPlataforma() {
        return idPlataforma;
    }
    public void setIdPlataforma(String idPlataforma) {
        this.idPlataforma = idPlataforma;
    }
    public Integer getAnoLancamento() {
        return anoLancamento;
    }
    public void setAnoLancamento(Integer anoLancamento) {
        this.anoLancamento = anoLancamento;
    }

    
    
}
