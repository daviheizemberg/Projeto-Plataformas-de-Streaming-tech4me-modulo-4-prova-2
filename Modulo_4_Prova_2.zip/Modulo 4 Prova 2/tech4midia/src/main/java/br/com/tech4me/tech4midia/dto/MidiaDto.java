package br.com.tech4me.tech4midia.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

public class MidiaDto {
    
    private String id;
    @Size(min = 3, message = "A descrição deve conter ao menos 3 caracteres")
    @NotBlank(message = "O campo deve ser informado")
    private String descricao;
    @NotNull(message = "O campo é obrigatório")
    @Positive
    private Integer anoLancamento;
    @Size(min = 5, message = "O gênero deve conter ao menos 3 caracteres")
    private String genero;
    @Positive
    private double nota;
    private String idPlataforma;

    public String getId() {
        return this.id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getDescricao() {
        return this.descricao;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    public String getGenero() {
        return this.genero;
    }
    public void setGenero(String genero) {
        this.genero = genero;
    }
    public double getNota() {
        return this.nota;
    }
    public void setNota(double nota) {
        this.nota = nota;
    }
    public String getIdPlataforma() {
        return idPlataforma;
    }
    public void setIdPlataforma(String idPlataforma) {
        this.idPlataforma = idPlataforma;
    }
    public Integer getAnoLancamento() {
        return anoLancamento;
    }
    public void setAnoLancamento(Integer anolancamento) {
        this.anoLancamento = anolancamento;
    }
}
