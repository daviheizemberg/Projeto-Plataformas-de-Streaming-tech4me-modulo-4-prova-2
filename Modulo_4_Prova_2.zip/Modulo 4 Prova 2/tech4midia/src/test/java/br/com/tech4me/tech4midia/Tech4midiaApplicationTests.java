package br.com.tech4me.tech4midia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tech4midiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
